make random_concatenation.out

date
folder=data/random2
#trial254-13 trial254-27 trial255-11
#trial256-106 trial256-111 trial256-134 trial256-141
for trial in trial264-12296 trial264-14671 trial264-14740 trial264-15340 trial264-8369
do
    title=$folder/$trial
    echo check $title
    ./random_concatenation.out 2 $title >>data/result/random2check/check-$trial.log &
#    ./random_concatenation.out 2 $title 
done
wait
echo done
date
